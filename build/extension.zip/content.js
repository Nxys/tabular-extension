// 浏览器框选复制插件 - 合并后的 Content Script
// 自动生成，请勿手动编辑

// === build/dist/types.js ===
{};


// === build/dist/components/selection.js ===
/**
 * 选择框组件 - 处理鼠标交互，创建和管理选择框UI
 */
class SelectionBox {
    selectionElement = null;
    startX = 0;
    startY = 0;
    isSelecting = false;
    isCompleted = false; // 选择是否已完成
    onSelectionComplete;
    constructor() {
        this.bindMouseEvents();
    }
    /**
     * 开始选择操作
     */
    startSelection(startX, startY) {
        this.startX = startX;
        this.startY = startY;
        this.isSelecting = true;
        this.createSelectionElement();
    }
    /**
     * 更新选择框位置和大小
     */
    updateSelection(currentX, currentY) {
        if (!this.isSelecting || !this.selectionElement)
            return;
        // 计算选择框的位置和尺寸
        const left = Math.min(this.startX, currentX);
        const top = Math.min(this.startY, currentY);
        const width = Math.abs(currentX - this.startX);
        const height = Math.abs(currentY - this.startY);
        // 使用 !important 确保样式不被页面CSS覆盖
        this.selectionElement.style.setProperty('left', `${left}px`, 'important');
        this.selectionElement.style.setProperty('top', `${top}px`, 'important');
        this.selectionElement.style.setProperty('width', `${width}px`, 'important');
        this.selectionElement.style.setProperty('height', `${height}px`, 'important');
    }
    /**
     * 完成选择操作并返回选择区域
     */
    finishSelection() {
        if (!this.selectionElement) {
            throw new Error('没有活动的选择框');
        }
        // 从样式中获取位置和尺寸，这些是页面坐标
        const left = parseInt(this.selectionElement.style.left) || 0;
        const top = parseInt(this.selectionElement.style.top) || 0;
        const width = parseInt(this.selectionElement.style.width) || 0;
        const height = parseInt(this.selectionElement.style.height) || 0;
        const selectionRect = {
            left: left,
            top: top,
            right: left + width,
            bottom: top + height
        };
        // 更新状态：选择完成但选择框保持可见
        this.isSelecting = false;
        this.isCompleted = true;
        return selectionRect;
    }
    /**
     * 清除选择框
     */
    clearSelection() {
        if (this.selectionElement) {
            this.selectionElement.remove();
            this.selectionElement = null;
        }
        this.isSelecting = false;
        this.isCompleted = false;
    }
    /**
     * 设置选择完成回调函数
     */
    setOnSelectionComplete(callback) {
        this.onSelectionComplete = callback;
    }
    /**
     * 检查是否正在选择
     */
    isCurrentlySelecting() {
        return this.isSelecting;
    }
    /**
     * 检查选择是否已完成
     */
    isSelectionCompleted() {
        return this.isCompleted;
    }
    /**
     * 检查是否有活动的选择框
     */
    hasActiveSelection() {
        return this.selectionElement !== null;
    }
    /**
     * 绑定鼠标事件处理器
     */
    bindMouseEvents() {
        // 鼠标按下事件 - 开始选择
        document.addEventListener('mousedown', this.handleMouseDown.bind(this));
        // 鼠标移动事件 - 更新选择框
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        // 鼠标释放事件 - 完成选择
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
        // 点击其他区域清除选择框
        document.addEventListener('click', this.handleClick.bind(this));
    }
    /**
     * 处理鼠标按下事件
     */
    handleMouseDown(event) {
        // 只处理左键点击
        if (event.button !== 0)
            return;
        // 防止在已有选择框上开始新选择
        if (event.target === this.selectionElement)
            return;
        // 如果已有完成的选择框，清除它以开始新选择
        if (this.isCompleted) {
            this.clearSelection();
        }
        // 阻止默认行为，避免文本选择
        event.preventDefault();
        // 获取鼠标位置（相对于页面）
        const startX = event.pageX;
        const startY = event.pageY;
        // 开始选择
        this.startSelection(startX, startY);
    }
    /**
     * 处理鼠标移动事件
     */
    handleMouseMove(event) {
        // 只在选择状态下处理移动
        if (!this.isSelecting)
            return;
        // 获取当前鼠标位置（相对于页面）
        const currentX = event.pageX;
        const currentY = event.pageY;
        // 更新选择框
        this.updateSelection(currentX, currentY);
    }
    /**
     * 处理鼠标释放事件
     */
    handleMouseUp(event) {
        // 只处理左键释放
        if (event.button !== 0)
            return;
        // 只在选择状态下处理释放
        if (!this.isSelecting)
            return;
        // 检查选择框是否足够大（至少5x5像素）
        if (this.selectionElement) {
            const width = parseInt(this.selectionElement.style.width) || 0;
            const height = parseInt(this.selectionElement.style.height) || 0;
            if (width < 5 || height < 5) {
                // 选择区域太小，清除选择框
                this.clearSelection();
                return;
            }
        }
        // 完成选择并获取选择区域
        const selectionRect = this.finishSelection();
        // 触发选择完成回调
        if (this.onSelectionComplete) {
            this.onSelectionComplete(selectionRect);
        }
    }
    /**
     * 处理点击事件 - 用于清除选择框
     */
    handleClick(event) {
        // 如果选择已完成且点击的不是选择框，清除选择框
        if (this.isCompleted &&
            this.selectionElement &&
            event.target !== this.selectionElement &&
            !this.selectionElement.contains(event.target)) {
            this.clearSelection();
        }
    }
    /**
     * 销毁组件，移除事件监听器
     */
    destroy() {
        document.removeEventListener('mousedown', this.handleMouseDown.bind(this));
        document.removeEventListener('mousemove', this.handleMouseMove.bind(this));
        document.removeEventListener('mouseup', this.handleMouseUp.bind(this));
        document.removeEventListener('click', this.handleClick.bind(this));
        this.clearSelection();
    }
    /**
     * 创建选择框DOM元素
     */
    createSelectionElement() {
        // 清除之前的选择框，但不重置 isSelecting 状态
        if (this.selectionElement) {
            this.selectionElement.remove();
            this.selectionElement = null;
        }
        this.selectionElement = document.createElement('div');
        this.selectionElement.className = 'browser-selection-copy-box';
        // 使用 setProperty 方法设置重要样式，确保在所有页面上都能正确显示
        const styles = {
            'position': 'absolute',
            'border': '2px dashed #007acc',
            'background-color': 'rgba(0, 122, 204, 0.1)',
            'pointer-events': 'none',
            'z-index': '2147483647',
            'box-sizing': 'border-box',
            'margin': '0',
            'padding': '0',
            'left': `${this.startX}px`,
            'top': `${this.startY}px`,
            'width': '0px',
            'height': '0px',
            'border-radius': '0',
            'outline': 'none',
            'box-shadow': 'none',
            'opacity': '1',
            'visibility': 'visible',
            'display': 'block',
            'transform': 'none',
            'transition': 'none'
        };
        // 应用所有样式，使用 important 优先级
        Object.entries(styles).forEach(([property, value]) => {
            this.selectionElement.style.setProperty(property, value, 'important');
        });
        document.body.appendChild(this.selectionElement);
    }
}


// === build/dist/components/extractor.js ===
/**
 * 视觉文本提取器 - 负责从选择区域提取和排序文本
 */
class VisualTextExtractor {
    LINE_TOLERANCE = 5; // 行分组的像素容差
    /**
     * 提取选择区域内的文本并按视觉顺序排列
     */
    extractText(selectionRect) {
        const textElements = this.getTextElements(selectionRect);
        const sortedElements = this.sortByVisualOrder(textElements);
        return this.combineTextElements(sortedElements);
    }
    /**
     * 获取选择区域内的所有文本元素
     */
    getTextElements(rect) {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
            acceptNode: (node) => {
                // 过滤空白和隐藏文本
                if (!node.textContent?.trim())
                    return NodeFilter.FILTER_REJECT;
                const parent = node.parentElement;
                if (!parent || !this.isVisible(parent))
                    return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        const elements = [];
        let node;
        while (node = walker.nextNode()) {
            const parent = node.parentElement;
            const rects = parent.getClientRects();
            // 检查每个rect是否与选择区域相交
            for (let i = 0; i < rects.length; i++) {
                const domRect = rects[i];
                if (this.intersects(domRect, rect)) {
                    elements.push({
                        text: node.textContent || '',
                        rect: domRect,
                        element: parent,
                        lineIndex: -1, // 稍后分配
                        columnIndex: -1 // 稍后分配
                    });
                    break; // 每个文本节点只添加一次
                }
            }
        }
        return elements;
    }
    /**
     * 按视觉顺序排序文本元素
     */
    sortByVisualOrder(elements) {
        // 1. 按Y坐标分组为视觉行
        const lines = this.groupIntoVisualLines(elements);
        // 2. 行内按X坐标排序
        lines.forEach(line => {
            line.elements.sort((a, b) => a.rect.left - b.rect.left);
            // 分配列索引
            line.elements.forEach((element, index) => {
                element.columnIndex = index;
            });
        });
        // 3. 按行顺序合并结果并分配行索引
        return lines
            .sort((a, b) => a.topY - b.topY)
            .flatMap((line, lineIndex) => {
            line.elements.forEach(element => {
                element.lineIndex = lineIndex;
            });
            return line.elements;
        });
    }
    /**
     * 检查元素是否可见
     */
    isVisible(element) {
        const style = window.getComputedStyle(element);
        return style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            style.opacity !== '0';
    }
    /**
     * 检查矩形是否与选择区域相交
     */
    intersects(rect, selection) {
        return !(rect.right < selection.left ||
            rect.left > selection.right ||
            rect.bottom < selection.top ||
            rect.top > selection.bottom);
    }
    /**
     * 将文本元素分组为视觉行
     */
    groupIntoVisualLines(elements) {
        const lines = [];
        elements.forEach(element => {
            const existingLine = lines.find(line => Math.abs(line.topY - element.rect.top) <= this.LINE_TOLERANCE);
            if (existingLine) {
                existingLine.elements.push(element);
                // 更新行边界
                existingLine.topY = Math.min(existingLine.topY, element.rect.top);
                existingLine.bottomY = Math.max(existingLine.bottomY, element.rect.bottom);
            }
            else {
                lines.push({
                    lineIndex: lines.length,
                    topY: element.rect.top,
                    bottomY: element.rect.bottom,
                    elements: [element]
                });
            }
        });
        return lines;
    }
    /**
     * 合并文本元素为最终字符串
     */
    combineTextElements(elements) {
        if (elements.length === 0)
            return '';
        let result = '';
        let currentLineIndex = -1;
        elements.forEach((element, index) => {
            // 如果是新行，添加换行符（除了第一行）
            if (element.lineIndex !== currentLineIndex) {
                if (currentLineIndex !== -1) {
                    result += '\n';
                }
                currentLineIndex = element.lineIndex;
            }
            else if (index > 0) {
                // 同行内添加空格分隔
                result += ' ';
            }
            result += element.text.trim();
        });
        return result;
    }
}


// === build/dist/components/panel.js ===
/**
 * 结果面板组件 - 显示提取结果和提供复制功能
 */
class ResultPanel {
    panelElement = null;
    currentText = '';
    outsideClickHandler = null;
    keydownHandler = null;
    /**
     * 显示提取结果
     */
    showResult(text) {
        this.currentText = text;
        this.createPanel();
        this.updateContent();
    }
    /**
     * 隐藏面板
     */
    hide() {
        if (this.panelElement) {
            this.panelElement.remove();
            this.panelElement = null;
        }
        // 清理事件监听器
        this.removeOutsideClickListener();
        this.removeKeydownListener();
    }
    /**
     * 复制文本到剪贴板
     */
    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showCopyFeedback(true);
            return true;
        }
        catch (error) {
            console.warn('剪贴板写入失败，尝试降级方案:', error);
            this.fallbackCopy(text);
            return false;
        }
    }
    /**
     * 创建结果面板DOM元素
     */
    createPanel() {
        this.hide(); // 清除之前的面板
        this.panelElement = document.createElement('div');
        this.panelElement.className = 'browser-selection-copy-panel';
        this.panelElement.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      width: 300px;
      max-height: 400px;
      background: white;
      border: 1px solid #ccc;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: 1000000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
    `;
        document.body.appendChild(this.panelElement);
        // 添加交互事件监听（延迟添加，避免立即触发）
        setTimeout(() => {
            this.addOutsideClickListener();
            this.addKeydownListener();
        }, 0);
    }
    /**
     * 更新面板内容
     */
    updateContent() {
        if (!this.panelElement)
            return;
        const header = document.createElement('div');
        header.style.cssText = `
      padding: 12px 16px;
      border-bottom: 1px solid #eee;
      font-weight: 600;
      color: #333;
    `;
        header.textContent = '提取的文本';
        const content = document.createElement('div');
        content.style.cssText = `
      padding: 12px 16px;
      max-height: 200px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-wrap: break-word;
      color: #666;
      line-height: 1.4;
    `;
        content.textContent = this.currentText || '未检测到文本';
        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = `
      padding: 12px 16px;
      border-top: 1px solid #eee;
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    `;
        const copyButton = document.createElement('button');
        copyButton.style.cssText = `
      padding: 6px 12px;
      background: #007acc;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
    `;
        copyButton.textContent = '复制';
        copyButton.onclick = () => this.copyToClipboard(this.currentText);
        const closeButton = document.createElement('button');
        closeButton.style.cssText = `
      padding: 6px 12px;
      background: #f5f5f5;
      color: #666;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
    `;
        closeButton.textContent = '关闭';
        closeButton.onclick = () => this.hide();
        buttonContainer.appendChild(copyButton);
        buttonContainer.appendChild(closeButton);
        this.panelElement.appendChild(header);
        this.panelElement.appendChild(content);
        this.panelElement.appendChild(buttonContainer);
    }
    /**
     * 显示复制反馈
     */
    showCopyFeedback(success) {
        const feedback = document.createElement('div');
        feedback.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      padding: 12px 24px;
      background: ${success ? '#4caf50' : '#f44336'};
      color: white;
      border-radius: 4px;
      z-index: 1000001;
      font-size: 14px;
    `;
        feedback.textContent = success ? '复制成功！' : '复制失败，请手动复制';
        document.body.appendChild(feedback);
        setTimeout(() => {
            feedback.remove();
        }, 2000);
    }
    /**
     * 降级复制方案 - 选择文本让用户手动复制
     */
    fallbackCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 2em;
      height: 2em;
      padding: 0;
      border: none;
      outline: none;
      box-shadow: none;
      background: transparent;
    `;
        document.body.appendChild(textArea);
        textArea.select();
        textArea.setSelectionRange(0, 99999);
        try {
            document.execCommand('copy');
            this.showCopyFeedback(true);
        }
        catch (err) {
            this.showCopyFeedback(false);
        }
        document.body.removeChild(textArea);
    }
    /**
     * 添加外部点击事件监听器
     */
    addOutsideClickListener() {
        if (!this.outsideClickHandler) {
            this.outsideClickHandler = this.handleOutsideClick.bind(this);
            document.addEventListener('click', this.outsideClickHandler, true);
        }
    }
    /**
     * 移除外部点击事件监听器
     */
    removeOutsideClickListener() {
        if (this.outsideClickHandler) {
            document.removeEventListener('click', this.outsideClickHandler, true);
            this.outsideClickHandler = null;
        }
    }
    /**
     * 添加键盘事件监听器
     */
    addKeydownListener() {
        if (!this.keydownHandler) {
            this.keydownHandler = this.handleKeydown.bind(this);
            document.addEventListener('keydown', this.keydownHandler, true);
        }
    }
    /**
     * 移除键盘事件监听器
     */
    removeKeydownListener() {
        if (this.keydownHandler) {
            document.removeEventListener('keydown', this.keydownHandler, true);
            this.keydownHandler = null;
        }
    }
    /**
     * 处理点击外部区域隐藏面板
     */
    handleOutsideClick(event) {
        const target = event.target;
        // 检查点击是否在面板外部
        if (this.panelElement && !this.panelElement.contains(target)) {
            this.hide();
        }
    }
    /**
     * 处理键盘事件（ESC 键隐藏面板）
     */
    handleKeydown(event) {
        if (event.key === 'Escape' && this.panelElement) {
            event.preventDefault();
            event.stopPropagation();
            this.hide();
        }
    }
}


// === build/dist/main.js ===



/**
 * 主控制器 - 协调各组件交互，管理完整的用户操作流程
 */
class MainController {
    selectionBox;
    textExtractor;
    resultPanel;
    isActive = false;
    constructor() {
        this.selectionBox = new SelectionBox();
        this.textExtractor = new VisualTextExtractor();
        this.resultPanel = new ResultPanel();
    }
    /**
     * 初始化控制器，绑定事件监听器
     */
    initialize() {
        if (this.isActive)
            return;
        this.isActive = true;
        this.bindEvents();
    }
    /**
     * 销毁控制器，清理资源
     */
    destroy() {
        if (!this.isActive)
            return;
        this.isActive = false;
        this.unbindEvents();
        this.selectionBox.clearSelection();
        this.resultPanel.hide();
    }
    /**
     * 绑定鼠标事件监听器
     */
    bindEvents() {
        document.addEventListener('mousedown', this.handleMouseDown.bind(this));
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
    }
    /**
     * 解绑事件监听器
     */
    unbindEvents() {
        document.removeEventListener('mousedown', this.handleMouseDown.bind(this));
        document.removeEventListener('mousemove', this.handleMouseMove.bind(this));
        document.removeEventListener('mouseup', this.handleMouseUp.bind(this));
    }
    /**
     * 处理鼠标按下事件
     */
    handleMouseDown(event) {
        // 忽略右键和中键
        if (event.button !== 0)
            return;
        // 忽略在结果面板上的点击
        const target = event.target;
        if (target.closest('.browser-selection-copy-panel'))
            return;
        // 清除之前的结果面板
        this.resultPanel.hide();
        // 开始新的选择
        this.selectionBox.startSelection(event.pageX, event.pageY);
        event.preventDefault();
    }
    /**
     * 处理鼠标移动事件
     */
    handleMouseMove(event) {
        this.selectionBox.updateSelection(event.pageX, event.pageY);
    }
    /**
     * 处理鼠标释放事件
     */
    handleMouseUp(event) {
        try {
            const selectionRect = this.selectionBox.finishSelection();
            // 检查选择区域是否足够大
            const minSize = 10; // 最小选择区域像素
            const width = selectionRect.right - selectionRect.left;
            const height = selectionRect.bottom - selectionRect.top;
            if (width < minSize || height < minSize) {
                this.selectionBox.clearSelection();
                return;
            }
            // 提取文本
            const extractedText = this.textExtractor.extractText(selectionRect);
            // 清除选择框
            this.selectionBox.clearSelection();
            // 显示结果
            if (extractedText.trim()) {
                this.resultPanel.showResult(extractedText);
            }
            else {
                // 显示无文本提示
                this.showNoTextFeedback(event.pageX, event.pageY);
            }
        }
        catch (error) {
            console.error('文本提取过程中发生错误:', error);
            this.selectionBox.clearSelection();
            this.showErrorFeedback();
        }
    }
    /**
     * 显示无文本反馈
     */
    showNoTextFeedback(x, y) {
        const feedback = document.createElement('div');
        feedback.style.cssText = `
      position: absolute;
      left: ${x}px;
      top: ${y}px;
      padding: 8px 12px;
      background: rgba(0, 0, 0, 0.8);
      color: white;
      border-radius: 4px;
      font-size: 12px;
      z-index: 1000000;
      pointer-events: none;
    `;
        feedback.textContent = '未检测到文本';
        document.body.appendChild(feedback);
        setTimeout(() => {
            feedback.remove();
        }, 2000);
    }
    /**
     * 显示错误反馈
     */
    showErrorFeedback() {
        const feedback = document.createElement('div');
        feedback.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      padding: 12px 24px;
      background: #f44336;
      color: white;
      border-radius: 4px;
      z-index: 1000001;
      font-size: 14px;
    `;
        feedback.textContent = '文本提取失败，请重新尝试';
        document.body.appendChild(feedback);
        setTimeout(() => {
            feedback.remove();
        }, 3000);
    }
}



// === 初始化代码 ===
(function() {
  // 检查是否已经初始化过
  if (window.browserSelectionCopyController) {
    return;
  }

  try {
    // 创建主控制器实例
    const controller = new MainController();
    
    // 将控制器实例保存到全局，避免重复初始化
    window.browserSelectionCopyController = controller;
    
    // 初始化控制器
    controller.initialize();
    
    console.log('浏览器框选复制插件已初始化');
  } catch (error) {
    console.error('插件初始化失败:', error);
  }
})();
